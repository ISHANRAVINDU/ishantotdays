<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<?php 

	class animal
	{
		public $family;
		public $food;

		public function __construct($family,$food)
		{
			$this->family=$family;
			$this->food=$food;
		}

		public function decl()
		{
			echo "The animal is {$this->family} and the food is {$this->food}";
		}
	}

	class Cat extends animal
	{
		public function message()
		{
			echo "";
		} 
	}

	$cat = new Cat("animal","fish");
	$cat->message();
	$cat->decl();

	 ?>

</body>
</html>